library(plumber)
library(tidyverse)
library(Matrix)
library(xgboost)
library(magrittr)
library(ElemStatLearn)
library(caret)
library(DALEX)

## load the model
modellist <- readRDS("xgbmodel.rds")
modelMatrix = modellist$modelMartix
bst.train = modellist$bst.train


#* @apiTitle GIST Diagnosis Model from PKUPH
#* @apiDescription Based on a gradient-boosting machine
#* @apiVersion 1.0.1

#* Plot
#* @param Long.Short.Diameter
#* @param CT.Value
#* @param Homogeneously.Enhanced
#* @param Ulcer
#* @param Liquid.Area
#* @param Lymphcte.Count
#* @serializer png
#* @get /plot
Predictions <- function(Long.Short.Diameter, CT.Value, Homogeneously.Enhanced, Ulcer, Liquid.Area, Lymphcte.Count){
  Long.Short.Diameter <- as.numeric(Long.Short.Diameter)
  CT.Value <- as.numeric(CT.Value)
  Homogeneously.Enhanced <- as.numeric(Homogeneously.Enhanced)
  Ulcer <- as.numeric(Ulcer)
  Liquid.Area <- as.numeric(Liquid.Area)
  Lymphcte.Count <- as.numeric(Lymphcte.Count)
  
  datanew <- data.frame(GIST = as.numeric(1), 
                        Long.Short.Diameter = Long.Short.Diameter, 
                        CT.Value = CT.Value, 
                        Homogeneously.Enhanced = Homogeneously.Enhanced, 
                        Ulcer = Ulcer, 
                        Liquid.Area = Liquid.Area, 
                        Lymphcte.Count = Lymphcte.Count)
  
  PPP <- modellist$NewPredictions(model = modellist$modelobject, newdata = datanew)
  return(plot(PPP))
}
