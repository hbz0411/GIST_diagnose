## load the libraries first.
library(tidyverse)
library(Matrix)
library(xgboost)
library(magrittr)
library(ElemStatLearn)
library(caret)
library(DALEX)

## load the model data.
modellist <- readRDS("xgbmodel.rds")
modelMatrix = modellist$modelMartix
bst.train = modellist$bst.train

## This is the function for use.
Predictions <- function(Long.Diameter, Short.Diameter, CT.Value, Arterial.Phase.CT.Value, Venous.Phase.CT.Value, Liquid.Area.Inside, Calcification){
  Long.Diameter <- as.numeric(Long.Diameter)
  Short.Diameter <- as.numeric(Short.Diameter)
  CT.Value <- as.numeric(CT.Value)
  Arterial.Phase.CT.Value <- as.numeric(Arterial.Phase.CT.Value)
  Venous.Phase.CT.Value <- as.numeric(Venous.Phase.CT.Value)
  Liquid.Area.Inside <- as.numeric(Liquid.Area.Inside)
  Calcification <- as.numeric(Calcification)
  
  Long.Short.Diameter = as.numeric(Long.Diameter/Short.Diameter)
  Arterial.Phase.Enhancement = as.numeric(Arterial.Phase.CT.Value - CT.Value)
  Venous.Phase.Enhancement = as.numeric(Venous.Phase.CT.Value - CT.Value)
  
  datanew <- data.frame(GIST = as.numeric(1), 
                        Long.Short.Diameter = Long.Short.Diameter, 
                        CT.Value = CT.Value, 
                        Arterial.Phase.Enhancement = Arterial.Phase.Enhancement, 
                        Venous.Phase.Enhancement = Venous.Phase.Enhancement,
                        Calcification = Calcification, 
                        Liquid.Area.Inside = Liquid.Area.Inside)
  
  PPP <- modellist$NewPredictions(model = modellist$modelobject, newdata = datanew)
  
  return(plot(PPP))
}

## Please use the function "Predictions()" for model prediction. 
## Function "Predictons()" has 7 variables that need to be input. 
## They are Long.Diameter, Short.Diameter, CT.Value, Arterial.Phase.CT.Value, Venous.Phase.CT.Value, Liquid.Area.Inside, Calcification. 

## Welcome to have a try~ 

##### Here is an EXAMPLE #####
Predictions(4.1, 3.9, 31, 45, 79, 1, 0)
